import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder

def prepare_data_ae(original_data):
    distinct_activities = original_data['EconAct'].unique()
    original_data['ConsLDayMeter'] = original_data['ConsLDay'] /original_data['NumMeters']
    columns_to_drop = ['Muni', 'ConsLDay', 'NumMeters']
    original_data = original_data.drop(columns=columns_to_drop)

    #print('checkpoint1 data loaded)')
    
    # Group the DataFrame by 'District', 'Use', and 'Type of economic activity'
    grouped_data = original_data.groupby(['PCode', 'Use', 'EconAct'])

    pcode_activity_dataframes = {}
    reshaped_data_list = []
    dataframes = []
    
    #print('checkpoint2 grouped data)')
    #print(grouped_data.head())

    for (pcode, use, activity), data in grouped_data:
        key = f'{pcode}_{use}_{activity}'  
        pcode, use, activity = key.split('_')
    
        pcode_activity_dataframes[key] = data.copy()
        pcode_activity_dataframes[key]['Date'] = pd.to_datetime(pcode_activity_dataframes[key][['Year', 'Month', 'Day']])
        pcode_activity_dataframes[key] = pcode_activity_dataframes[key].sort_values(by='Date', ascending=True)
       
        label_encoder = LabelEncoder()

        df_encoded = pcode_activity_dataframes[key]

        #print(df_encoded.head())

        df_encoded['PCode'] = label_encoder.fit_transform(df_encoded['PCode'])
        df_encoded['Use'] = label_encoder.fit_transform(df_encoded['Use'])
        df_encoded['EconAct'] = label_encoder.fit_transform(df_encoded['EconAct'])
        
        df_encoded.reset_index(inplace=True)
        
        #print('checkpoint3 before aggr)')
        #print(df_encoded.head())
        #print(df_encoded.info())


        df_encoded = df_encoded.groupby('Date').agg({
            'PCode': 'first',
            'Year': 'first',
            'Month': 'first',
            'Day':'first',
            'Use': 'first',
            'EconAct':'first',
            'ConsLDayMeter': 'max',
            'Precip': 'mean',  
            'Date' : 'first', 
            'T_max': 'mean',
            'T_min': 'mean',  
            'spi_12': 'mean',
            'spi_9': 'mean',
            'scpdsi': 'mean',
            'Dist': 'first',
            'WDay': 'first',
            'Day_Yr': 'first',
            'Price_m2': 'first',
            'ShopAge': 'first',
            'BldgAge': 'first',
            'Pop': 'first',
            'NumHH': 'first',
            'AvgPPHH': 'first',
            'NetIncPP': 'first',
            'NetIncHH': 'first',
            'IncPC': 'first',
            'MedIncPC': 'first',
            'GrossIncPP': 'first',
            'GrossIncHH': 'first',
            'Pop0_14': 'first',
            'Pop15_64': 'first',
            'Pop65_': 'first',
            'MedAge': 'first',
            'ForBorn': 'first',
            'Foreigners': 'first',
            'BirthRate': 'first',
            'DeathRate': 'first',
            'LifeExp': 'first',
            'NumChild': 'first',
            'UnempRate': 'first',
            'EmpRate': 'first',
            'ActRate': 'first',
            'ServEmp': 'first',
            'IndEmp': 'first',
            'Area': 'first',
            'ChildCare': 'first'

        }).reset_index(drop=True)
   
        

        data = df_encoded.values
        pcode_activity_dataframes[key] = df_encoded
        
        if (data.shape[0]) == 1461 :
            reshaped_data_list.append(data)

    reshaped_data = np.stack(reshaped_data_list, axis=0)

    return reshaped_data, pcode_activity_dataframes

if __name__ == '__main__':
    path = '/Users/nicolasvila/workplace/uni/ABData/abdataset1_barcelona_temp_seq.csv'
    prepare_data_ae(path)
